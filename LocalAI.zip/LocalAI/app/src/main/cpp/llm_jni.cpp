#include <jni.h>
#include <android/log.h>
#include <atomic>
#include <mutex>
#include <string>
#include <vector>

#include "llama.h"

#define TAG "LocalAI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static llama_model *g_model = nullptr;
static llama_context *g_ctx = nullptr;
static std::mutex g_mutex;
static std::atomic<bool> g_stop{false};

// Длина самого длинного префикса строки, не обрывающегося посреди UTF-8 символа.
static size_t valid_utf8_prefix(const std::string &s) {
    size_t n = s.size();
    for (size_t back = 1; back <= 3 && back <= n; ++back) {
        unsigned char c = (unsigned char) s[n - back];
        if ((c & 0xC0) == 0x80) continue;  // байт-продолжение, ищем начало
        size_t need = (c >= 0xF0) ? 4 : (c >= 0xE0) ? 3 : (c >= 0xC0) ? 2 : 1;
        return need > back ? n - back : n;
    }
    return n;
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_localai_app_engine_NativeLlm_load(JNIEnv *env, jobject, jstring jpath, jint nCtx, jint threads) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }

    const char *path = env->GetStringUTFChars(jpath, nullptr);
    llama_backend_init();

    llama_model_params mp = llama_model_default_params();
    mp.use_mmap = true;
    g_model = llama_model_load_from_file(path, mp);
    env->ReleaseStringUTFChars(jpath, path);
    if (!g_model) { LOGE("model load failed"); return JNI_FALSE; }

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = nCtx;
    cp.n_batch = nCtx;
    cp.n_threads = threads;
    cp.n_threads_batch = threads;
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) { LOGE("context init failed"); return JNI_FALSE; }
    LOGI("model loaded, n_ctx=%d threads=%d", (int) nCtx, (int) threads);
    return JNI_TRUE;
}

// Возвращает число токенов промпта (для обрезки истории в Kotlin), -1 если модель не загружена.
extern "C" JNIEXPORT jint JNICALL
Java_com_localai_app_engine_NativeLlm_countTokens(JNIEnv *env, jobject, jstring jtext) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (!g_model) return -1;
    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    const char *text = env->GetStringUTFChars(jtext, nullptr);
    std::string s(text);
    env->ReleaseStringUTFChars(jtext, text);
    int n = -llama_tokenize(vocab, s.c_str(), (int) s.size(), nullptr, 0, false, true);
    return n;
}

extern "C" JNIEXPORT void JNICALL
Java_com_localai_app_engine_NativeLlm_generate(JNIEnv *env, jobject, jstring jprompt, jint maxTokens, jobject cb) {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_stop = false;
    if (!g_model || !g_ctx) return;

    jclass cbCls = env->GetObjectClass(cb);
    jmethodID onToken = env->GetMethodID(cbCls, "onToken", "([B)Z");
    if (!onToken) return;

    const llama_vocab *vocab = llama_model_get_vocab(g_model);
    const char *p = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(p);
    env->ReleaseStringUTFChars(jprompt, p);

    int nPrompt = -llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), nullptr, 0, false, true);
    if (nPrompt <= 0) return;
    std::vector<llama_token> toks(nPrompt);
    if (llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), toks.data(), nPrompt, false, true) < 0) return;
    if (nPrompt >= (int) llama_n_ctx(g_ctx) - 8) { LOGE("prompt too long: %d", nPrompt); return; }

    llama_kv_self_clear(g_ctx);

    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_penalties(64, 1.1f, 0.0f, 0.0f));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
    llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
    llama_sampler_chain_add(smpl, llama_sampler_init_temp(0.7f));
    llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));

    llama_token next;
    llama_batch batch = llama_batch_get_one(toks.data(), (int) toks.size());
    std::string pending;
    int generated = 0;
    int nCtx = (int) llama_n_ctx(g_ctx);
    int used = (int) toks.size();

    while (generated < maxTokens && used < nCtx - 1 && !g_stop.load()) {
        if (llama_decode(g_ctx, batch) != 0) { LOGE("decode failed"); break; }
        next = llama_sampler_sample(smpl, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, next)) break;

        char buf[256];
        int n = llama_token_to_piece(vocab, next, buf, sizeof(buf), 0, false);
        if (n > 0) pending.append(buf, n);

        size_t ok = valid_utf8_prefix(pending);
        if (ok > 0) {
            jbyteArray arr = env->NewByteArray((jsize) ok);
            env->SetByteArrayRegion(arr, 0, (jsize) ok, (const jbyte *) pending.data());
            jboolean cont = env->CallBooleanMethod(cb, onToken, arr);
            env->DeleteLocalRef(arr);
            pending.erase(0, ok);
            if (!cont || env->ExceptionCheck()) { env->ExceptionClear(); break; }
        }
        batch = llama_batch_get_one(&next, 1);
        generated++;
        used++;
    }
    llama_sampler_free(smpl);
}

extern "C" JNIEXPORT void JNICALL
Java_com_localai_app_engine_NativeLlm_stop(JNIEnv *, jobject) {
    g_stop = true;
}

extern "C" JNIEXPORT void JNICALL
Java_com_localai_app_engine_NativeLlm_unload(JNIEnv *, jobject) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_ctx) { llama_free(g_ctx); g_ctx = nullptr; }
    if (g_model) { llama_model_free(g_model); g_model = nullptr; }
}
