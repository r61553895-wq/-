package com.localai.app.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp

/** Матовое стекло: полупрозрачная заливка, светлая кромка сверху и мягкая тень снизу. */
@Composable
fun GlassSurface(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    alpha: Float = 0.08f,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = alpha + 0.05f), Color.White.copy(alpha = alpha))
                )
            )
            .border(
                1.dp,
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.28f), Color.White.copy(alpha = 0.06f))
                ),
                shape
            ),
        content = content
    )
}

/** Тёмно-серый фон с медленно плывущими световыми пятнами: их и «размывает» стекло. */
@Composable
fun GlassBackground(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "bg")
    val a by t.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(16000, easing = LinearEasing), RepeatMode.Reverse),
        label = "a"
    )
    val b by t.animateFloat(
        initialValue = 1f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(22000, easing = LinearEasing), RepeatMode.Reverse),
        label = "b"
    )
    Canvas(
        modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Pal.Bg1, Pal.Bg0)))
    ) {
        val m = size.minDimension
        blob(Offset(size.width * (0.15f + 0.6f * a), size.height * (0.12f + 0.2f * b)), m * 0.95f, 0.30f)
        blob(Offset(size.width * (0.85f - 0.6f * b), size.height * (0.55f + 0.2f * a)), m * 1.0f, 0.22f)
        blob(Offset(size.width * (0.3f + 0.4f * b), size.height * (0.92f - 0.15f * a)), m * 0.8f, 0.18f)
    }
}

private fun DrawScope.blob(center: Offset, radius: Float, strength: Float) {
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Pal.Blob.copy(alpha = strength), Color.Transparent),
            center = center,
            radius = radius
        ),
        radius = radius,
        center = center
    )
}
