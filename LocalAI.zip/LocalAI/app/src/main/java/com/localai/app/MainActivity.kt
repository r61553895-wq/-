package com.localai.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.localai.app.ui.ChatScreen
import com.localai.app.ui.GlassBackground
import com.localai.app.ui.LocalAiTheme
import com.localai.app.ui.SetupScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            LocalAiTheme {
                val vm: ChatViewModel = viewModel()
                val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) vm.importModel(uri)
                }
                Box(Modifier.fillMaxSize()) {
                    GlassBackground()
                    if (vm.modelState == ModelState.Ready) {
                        ChatScreen(vm)
                    } else {
                        SetupScreen(vm.modelState, onPick = { picker.launch(arrayOf("*/*")) })
                    }
                }
            }
        }
    }
}
