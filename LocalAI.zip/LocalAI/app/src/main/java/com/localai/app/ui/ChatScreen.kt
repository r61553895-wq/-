package com.localai.app.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localai.app.ChatViewModel
import com.localai.app.Message

@Composable
fun ChatScreen(vm: ChatViewModel) {
    val listState = rememberLazyListState()
    val lastLength = vm.messages.lastOrNull()?.text?.length

    LaunchedEffect(vm.messages.size, lastLength) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
    }

    Column(
        Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .imePadding()
            .navigationBarsPadding()
    ) {
        TopBar(vm.generating)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(vm.messages, key = { it.id }) { m ->
                    MessageBubble(m, Modifier.animateItem())
                }
            }
            AnimatedVisibility(
                visible = vm.messages.isEmpty(),
                modifier = Modifier.align(Alignment.Center),
                enter = fadeIn(tween(700)),
                exit = fadeOut(tween(250))
            ) { EmptyHint() }
        }
        InputBar(enabled = !vm.generating, onSend = vm::send)
    }
}

@Composable
private fun TopBar(busy: Boolean) {
    val t = rememberInfiniteTransition(label = "pulse")
    val pulse by t.animateFloat(
        initialValue = 0.35f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "p"
    )
    GlassSurface(
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
        shape = RoundedCornerShape(22.dp)
    ) {
        Row(
            Modifier.padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Local AI", color = Pal.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                AnimatedContent(targetState = busy, label = "status") { b ->
                    Text(
                        if (b) "Отвечает" else "Демо-режим, модель не подключена",
                        color = Pal.TextDim,
                        fontSize = 12.sp
                    )
                }
            }
            Box(
                Modifier
                    .size(10.dp)
                    .alpha(if (busy) pulse else 0.5f)
                    .background(Pal.Accent, CircleShape)
            )
        }
    }
}

@Composable
private fun MessageBubble(m: Message, modifier: Modifier = Modifier) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }

    AnimatedVisibility(
        visible = shown,
        modifier = modifier.fillMaxWidth(),
        enter = fadeIn(tween(380)) +
            slideInVertically(tween(380, easing = FastOutSlowInEasing)) { it / 3 } +
            scaleIn(
                tween(380, easing = FastOutSlowInEasing),
                initialScale = 0.92f,
                transformOrigin = TransformOrigin(if (m.fromUser) 1f else 0f, 1f)
            )
    ) {
        Box(
            Modifier.fillMaxWidth(),
            contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart
        ) {
            val shape = RoundedCornerShape(
                topStart = 22.dp,
                topEnd = 22.dp,
                bottomStart = if (m.fromUser) 22.dp else 6.dp,
                bottomEnd = if (m.fromUser) 6.dp else 22.dp
            )
            GlassSurface(
                Modifier.widthIn(max = 300.dp),
                shape = shape,
                alpha = if (m.fromUser) 0.16f else 0.07f
            ) {
                if (m.text.isEmpty()) {
                    TypingDots(Modifier.padding(horizontal = 18.dp, vertical = 16.dp))
                } else {
                    Text(
                        m.text,
                        color = Pal.Text,
                        fontSize = 16.sp,
                        lineHeight = 22.sp,
                        modifier = Modifier
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                            .animateContentSize()
                    )
                }
            }
        }
    }
}

@Composable
private fun TypingDots(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "dots")
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        repeat(3) { i ->
            val a by t.animateFloat(
                initialValue = 0.25f,
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    tween(600, easing = FastOutSlowInEasing),
                    RepeatMode.Reverse,
                    initialStartOffset = StartOffset(i * 180)
                ),
                label = "d$i"
            )
            Box(
                Modifier
                    .size(8.dp)
                    .alpha(a)
                    .background(Pal.Accent, CircleShape)
            )
        }
    }
}

@Composable
private fun EmptyHint() {
    GlassSurface(shape = RoundedCornerShape(26.dp)) {
        Column(
            Modifier.padding(horizontal = 28.dp, vertical = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Привет", color = Pal.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(6.dp))
            Text("Напиши первое сообщение", color = Pal.TextDim, fontSize = 14.sp)
        }
    }
}

@Composable
private fun InputBar(enabled: Boolean, onSend: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    val canSend = enabled && text.isNotBlank()

    GlassSurface(
        Modifier.padding(horizontal = 16.dp, vertical = 10.dp).fillMaxWidth(),
        shape = RoundedCornerShape(28.dp),
        alpha = 0.09f
    ) {
        Row(
            Modifier.padding(start = 20.dp, end = 8.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f).padding(vertical = 8.dp)) {
                if (text.isEmpty()) {
                    Text("Сообщение", color = Pal.TextDim, fontSize = 16.sp)
                }
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    textStyle = TextStyle(color = Pal.Text, fontSize = 16.sp),
                    cursorBrush = SolidColor(Pal.Accent),
                    maxLines = 5,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            SendButton(active = canSend) {
                onSend(text)
                text = ""
            }
        }
    }
}

@Composable
private fun SendButton(active: Boolean, onClick: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.86f else if (active) 1f else 0.9f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "scale"
    )
    val bg by animateColorAsState(
        targetValue = if (active) Pal.Accent else Color.White.copy(alpha = 0.10f),
        animationSpec = tween(250),
        label = "bg"
    )
    val arrow by animateColorAsState(
        targetValue = if (active) Pal.Bg0 else Pal.TextDim,
        animationSpec = tween(250),
        label = "arrow"
    )

    Box(
        Modifier
            .size(44.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .background(bg, CircleShape)
            .pointerInput(active) {
                detectTapGestures(
                    onPress = {
                        if (active) {
                            pressed = true
                            tryAwaitRelease()
                            pressed = false
                        }
                    },
                    onTap = { if (active) onClick() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(18.dp)) {
            val w = size.width
            val h = size.height
            val p = Path().apply {
                moveTo(w / 2, h * 0.9f)
                lineTo(w / 2, h * 0.15f)
                moveTo(w * 0.15f, h * 0.45f)
                lineTo(w / 2, h * 0.1f)
                lineTo(w * 0.85f, h * 0.45f)
            }
            drawPath(
                p,
                arrow,
                style = Stroke(width = 2.4.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
    }
}
