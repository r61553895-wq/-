package com.localai.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Pal {
    val Bg0 = Color(0xFF0B0C0E)
    val Bg1 = Color(0xFF17181B)
    val Blob = Color(0xFF8D9096)
    val Text = Color(0xFFECEDEF)
    val TextDim = Color(0xFF9A9DA3)
    val Accent = Color(0xFFD9DBDF)
}

@Composable
fun LocalAiTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Pal.Accent,
            background = Pal.Bg0,
            surface = Pal.Bg1,
            onSurface = Pal.Text
        ),
        content = content
    )
}
