package com.localai.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.localai.app.ModelState

/** Экран, пока модель не выбрана / копируется / загружается. */
@Composable
fun SetupScreen(state: ModelState, onPick: () -> Unit) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        GlassSurface(Modifier.fillMaxWidth(), alpha = 0.10f) {
            Column(
                Modifier.padding(24.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Local AI", color = Pal.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
                when (state) {
                    is ModelState.Copying -> {
                        Text("Копирую модель…", color = Pal.TextDim, fontSize = 15.sp)
                        LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                    }
                    ModelState.Loading -> {
                        Text("Загружаю модель в память…", color = Pal.TextDim, fontSize = 15.sp)
                        LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                    }
                    else -> {
                        val msg = if (state is ModelState.Failed) state.message
                        else "Выбери файл модели (.gguf). Он скопируется в приложение один раз."
                        Text(msg, color = Pal.TextDim, fontSize = 15.sp, textAlign = TextAlign.Center)
                        GlassSurface(
                            Modifier.fillMaxWidth().clickable(onClick = onPick),
                            shape = RoundedCornerShape(16.dp),
                            alpha = 0.14f
                        ) {
                            Text(
                                "Выбрать модель",
                                color = Pal.Text,
                                fontSize = 16.sp,
                                modifier = Modifier.padding(vertical = 14.dp).fillMaxWidth(),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}
