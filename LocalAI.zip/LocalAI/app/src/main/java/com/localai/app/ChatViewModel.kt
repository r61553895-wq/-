package com.localai.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.localai.app.engine.DemoEngine
import com.localai.app.engine.LlmEngine
import kotlinx.coroutines.launch

data class Message(val id: Long, val text: String, val fromUser: Boolean)

class ChatViewModel : ViewModel() {
    private val engine: LlmEngine = DemoEngine()
    private var nextId = 0L

    val messages = mutableStateListOf<Message>()
    var generating by mutableStateOf(false)
        private set

    fun send(text: String) {
        val prompt = text.trim()
        if (prompt.isEmpty() || generating) return
        messages.add(Message(nextId++, prompt, fromUser = true))
        val replyId = nextId++
        messages.add(Message(replyId, "", fromUser = false))
        generating = true
        viewModelScope.launch {
            var acc = ""
            try {
                engine.generate(prompt).collect {
                    acc += it
                    update(replyId, acc)
                }
            } finally {
                generating = false
            }
        }
    }

    private fun update(id: Long, text: String) {
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text)
    }
}
