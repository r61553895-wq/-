package com.localai.app

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.localai.app.engine.LlamaEngine
import com.localai.app.engine.LlmEngine
import com.localai.app.engine.NativeLlm
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

data class Message(val id: Long, val text: String, val fromUser: Boolean)

sealed interface ModelState {
    data object Missing : ModelState
    data class Copying(val progress: Float) : ModelState
    data object Loading : ModelState
    data object Ready : ModelState
    data class Failed(val message: String) : ModelState
}

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val native = NativeLlm()
    private var engine: LlmEngine? = null
    private val modelFile = File(app.filesDir, "model.gguf")
    private var nextId = 0L

    val messages = mutableStateListOf<Message>()
    var generating by mutableStateOf(false)
        private set
    var modelState by mutableStateOf<ModelState>(ModelState.Missing)
        private set

    init {
        if (modelFile.exists()) loadModel() else modelState = ModelState.Missing
    }

    /** Копируем выбранный пользователем .gguf в память приложения. */
    fun importModel(uri: Uri) {
        viewModelScope.launch {
            modelState = ModelState.Copying(0f)
            try {
                withContext(Dispatchers.IO) {
                    val cr = getApplication<Application>().contentResolver
                    val total = cr.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)
                        ?.use { if (it.moveToFirst()) it.getLong(0) else -1L } ?: -1L
                    val tmp = File(modelFile.parentFile, "model.gguf.part")
                    cr.openInputStream(uri)!!.use { input ->
                        tmp.outputStream().use { out ->
                            val buf = ByteArray(1 shl 20)
                            var done = 0L
                            var lastUi = 0L
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                out.write(buf, 0, n)
                                done += n
                                val now = System.currentTimeMillis()
                                if (total > 0 && now - lastUi > 200) {
                                    lastUi = now
                                    val pr = done.toFloat() / total
                                    withContext(Dispatchers.Main) { modelState = ModelState.Copying(pr) }
                                }
                            }
                        }
                    }
                    if (modelFile.exists()) modelFile.delete()
                    check(tmp.renameTo(modelFile)) { "не удалось сохранить файл" }
                }
                loadModel()
            } catch (e: Exception) {
                modelState = ModelState.Failed(e.message ?: "ошибка копирования")
            }
        }
    }

    private fun loadModel() {
        modelState = ModelState.Loading
        viewModelScope.launch {
            val ok = withContext(Dispatchers.Default) {
                try {
                    val threads = Runtime.getRuntime().availableProcessors().coerceIn(2, 6)
                    native.load(modelFile.absolutePath, 2048, threads)
                } catch (e: Throwable) {
                    false
                }
            }
            if (ok) {
                engine = LlamaEngine(native)
                modelState = ModelState.Ready
            } else {
                modelState = ModelState.Failed("Не удалось загрузить модель. Проверь, что это GGUF-файл.")
            }
        }
    }

    fun resetModel() {
        native.unload()
        modelFile.delete()
        engine = null
        modelState = ModelState.Missing
    }

    fun send(text: String) {
        val prompt = text.trim()
        val eng = engine ?: return
        if (prompt.isEmpty() || generating) return
        messages.add(Message(nextId++, prompt, fromUser = true))
        val replyId = nextId++
        messages.add(Message(replyId, "", fromUser = false))
        generating = true
        val history = messages.toList()
        viewModelScope.launch {
            var acc = ""
            try {
                eng.generate(history).collect {
                    acc += it
                    update(replyId, acc)
                }
            } finally {
                generating = false
            }
        }
    }

    private fun update(id: Long, text: String) {
        val i = messages.indexOfFirst { it.id == id }
        if (i >= 0) messages[i] = messages[i].copy(text = text)
    }
}
