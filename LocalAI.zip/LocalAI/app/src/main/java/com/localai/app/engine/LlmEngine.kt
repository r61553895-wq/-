package com.localai.app.engine

import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/** Точка подключения модели: сюда позже встанет реальный движок. */
interface LlmEngine {
    fun generate(prompt: String): Flow<String>
}

/** Временный движок: стримит слова так же, как будет стримить настоящая модель. */
class DemoEngine : LlmEngine {
    override fun generate(prompt: String): Flow<String> = flow {
        delay(700)
        val reply = "Сейчас работает демо-режим. Когда сюда подключится локальная модель, " +
            "ответы будут приходить точно так же, слово за словом."
        for (word in reply.split(" ")) {
            delay(70)
            emit("$word ")
        }
    }
}
