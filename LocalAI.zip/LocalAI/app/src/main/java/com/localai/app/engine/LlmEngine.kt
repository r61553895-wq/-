package com.localai.app.engine

import com.localai.app.Message
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.launch

/** Точка подключения модели. */
interface LlmEngine {
    fun generate(history: List<Message>): Flow<String>
}

/** Колбэк из нативного кода: вернуть false, чтобы остановить генерацию. */
fun interface TokenCallback {
    fun onToken(bytes: ByteArray): Boolean
}

/** Обёртка над libllama (см. src/main/cpp/llm_jni.cpp). */
class NativeLlm {
    companion object {
        init { System.loadLibrary("localai_jni") }
    }

    external fun load(path: String, nCtx: Int, threads: Int): Boolean
    external fun countTokens(text: String): Int
    external fun generate(prompt: String, maxTokens: Int, cb: TokenCallback)
    external fun stop()
    external fun unload()
}

/** Настоящая модель (Qwen2.5 Instruct в формате GGUF). */
class LlamaEngine(
    private val native: NativeLlm,
    private val systemPrompt: String = "Ты — полезный ассистент. Отвечай на языке пользователя, кратко и по делу.",
    private val nCtx: Int = 2048,
    private val maxNewTokens: Int = 512
) : LlmEngine {

    override fun generate(history: List<Message>): Flow<String> = callbackFlow {
        val prompt = buildPrompt(history)
        launch(Dispatchers.Default) {
            native.generate(prompt, maxNewTokens) { bytes -> trySend(String(bytes, Charsets.UTF_8)).isSuccess }
            close()
        }
        awaitClose { native.stop() }
    }

    /** Формат ChatML, который использует Qwen. Старые сообщения отбрасываем, пока не влезем в контекст. */
    private fun buildPrompt(history: List<Message>): String {
        var from = 0
        while (true) {
            val p = render(history.subList(from, history.size))
            val n = native.countTokens(p)
            if (n < 0 || n <= nCtx - maxNewTokens || from >= history.size - 1) return p
            from++
        }
    }

    private fun render(msgs: List<Message>): String {
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n").append(systemPrompt).append("<|im_end|>\n")
        for (m in msgs) {
            if (m.text.isEmpty()) continue  // пустой «пузырь» ответа, который сейчас заполняется
            sb.append("<|im_start|>").append(if (m.fromUser) "user" else "assistant").append('\n')
                .append(m.text).append("<|im_end|>\n")
        }
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }
}

/** Запасной движок без модели. */
class DemoEngine : LlmEngine {
    override fun generate(history: List<Message>): Flow<String> = flow {
        delay(700)
        for (word in "Модель не загружена. Выбери файл .gguf.".split(" ")) {
            delay(70)
            emit("$word ")
        }
    }
}
